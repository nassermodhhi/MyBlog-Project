
from django.db import models

class User(models.Model):
    username = models.CharField(max_length=100)
    email = models.EmailField()


class blog(models.Model):
    title = models.CharField(max_length=100)
    content = models.TextField()
    category = models.ForeignKey('Category', on_delete=models.CASCADE)

class Comment(models.Model):
    content = models.TextField()
    blog = models.ForeignKey('Blog', on_delete=models.CASCADE)

class Category(models.Model):
    name = models.CharField(max_length=100)
