from django.contrib import admin
from .models import User, blog, Comment, Category

admin.site.register(User)
admin.site.register(blog)
admin.site.register(Comment)
admin.site.register(Category)