from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from .models import blog

def blog_list(request):
    my_blogs = blog.objects.all().values()
    template = loader.get_template('base.html')
    context = {
        'my_blogs': my_blogs,
    }
    return HttpResponse(template.render(context, request))

def index(request):
    return render(request, 'index.html')

def users(request):
    return render(request, 'users.html')

def blogs(request):
    return render(request, 'blogs.html')

def blog_details(request):
    return render(request, 'blog_details.html')

def comments(request):
    return render(request, 'comments.html')

def categories(request):
    return render(request, 'categories.html')

